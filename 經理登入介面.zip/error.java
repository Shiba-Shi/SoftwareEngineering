package SoftwareEngineering;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class error extends JFrame{
    private JButton sel;
    private JLabel message;

    public error(String s) {
        this.setTitle("錯誤");
        this.setLayout(null);
        this.setSize(300, 125);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setLocation(650, 350);

        message = new JLabel(s);
        message.setBounds(65, 0, 200, 50);
        message.setFont(new Font("微軟正黑體", Font.BOLD, 15));
        add(message);

        sel = new JButton("確定");
        sel.setBounds(90, 50, 100, 30);
        sel.addActionListener(new ActionListener() { 
            public void actionPerformed(ActionEvent e) { 
                dispose();
            } 
        });
        add(sel);

    }
    public static void main(String[] args) {
        error frame = new error("確認密碼與密碼不相同");
        frame.setVisible(true);
    }
}
