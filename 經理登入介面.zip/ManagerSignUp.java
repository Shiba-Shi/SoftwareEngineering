package SoftwareEngineering;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.json.JSONObject;

import javax.swing.JFormattedTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;

public class ManagerSignUp extends JFrame {
    private JLabel title, account, verify, password;
    private JButton sign_up;
    private JFormattedTextField enter_ac, enter_ps, enter_verrify;
    private String user_password, user_account, user_verify;

    public ManagerSignUp() {
        this.setTitle("註冊");
        this.setLayout(null);
        this.setSize(900, 600);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        title = new JLabel("經理註冊");
        title.setBounds(350, 50, 500, 100);
        title.setFont(new Font("微軟正黑體", Font.BOLD, 50));
        add(title);

        account = new JLabel("帳號");
        account.setBounds(250, 200, 100, 100);
        account.setFont(new Font("微軟正黑體", Font.BOLD, 20));
        add(account);

        enter_ac = new JFormattedTextField();
        enter_ac.setBounds(300, 232, 300, 40);
        add(enter_ac);

        password = new JLabel("密碼");
        password.setBounds(250, 275, 100, 100);
        password.setFont(new Font("微軟正黑體", Font.BOLD, 20));
        add(password);

        verify = new JLabel("確認");
        verify.setBounds(250, 350, 100, 100);
        verify.setFont(new Font("微軟正黑體", Font.BOLD, 20));
        add(verify);

        enter_verrify = new JFormattedTextField();
        enter_verrify.setBounds(300, 382, 300, 40);
        add(enter_verrify);

        enter_ps = new JFormattedTextField();
        enter_ps.setBounds(300, 307, 300, 40);
        add(enter_ps);

        sign_up = new JButton("註冊");
        sign_up.setBounds(375, 450, 125, 50);
        sign_up.setFont(new Font("微軟正黑體", Font.BOLD, 15));
        sign_up.addActionListener(new ActionListener() { 
            public void actionPerformed(ActionEvent e) { 
                user_account = enter_ac.getText();
                user_password = enter_ps.getText();
                user_verify = enter_verrify.getText();
                
                if (user_verify.equals(user_password) && user_account.length() != 0) {
                    System.out.println(user_password);
                    System.out.println(user_account);
                    String file_path = "user";
                    JSONObject json = new JSONObject();
                    json.put("account", user_account);
                    json.put("password", user_password);
                    new CreateFileUtil(file_path, json.toString());
                    error secondframe = new error("註冊成功!請重新登入");
                    secondframe.setVisible(true);
                    dispose();
                }else {
                    if (user_account.length() == 0) {
                        error secondframe = new error("     帳號欄位空白");
                        secondframe.setVisible(true);
                    }else {
                        error secondframe = new error("密碼與確認密碼不同");
                        secondframe.setVisible(true);
                    }
                    System.out.println("error");
                }
            } 
        });
        add(sign_up);
    }
    public static void main(String[] args) {
        ManagerSignUp frame = new ManagerSignUp();
        frame.setVisible(true);
    }
}