package SoftwareEngineering;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;

import java.awt.Font;

public class ManagerEnterPort extends JFrame{
    private JLabel title, account, password;
    private JButton sign_in, sign_up;
    private JFormattedTextField enter_ac, enter_ps;

    public ManagerEnterPort() {
        this.setTitle("登入");
        this.setLayout(null);
        this.setSize(900, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        title = new JLabel("經理登入");
        title.setBounds(350, 50, 500, 100);
        title.setFont(new Font("微軟正黑體", Font.BOLD, 50));
        add(title);

        account = new JLabel("帳號");
        account.setBounds(250, 200, 100, 100);
        account.setFont(new Font("微軟正黑體", Font.BOLD, 20));
        add(account);

        enter_ac = new JFormattedTextField();
        enter_ac.setBounds(300, 232, 300, 40);
        add(enter_ac);

        password = new JLabel("密碼");
        password.setBounds(250, 275, 100, 100);
        password.setFont(new Font("微軟正黑體", Font.BOLD, 20));
        add(password);

        enter_ps = new JFormattedTextField();
        enter_ps.setBounds(300, 307, 300, 40);
        add(enter_ps);

        sign_up = new JButton("註冊");
        sign_up.setBounds(300, 400, 125, 50);
        sign_up.setFont(new Font("微軟正黑體", Font.BOLD, 15));
        add(sign_up);

        sign_in = new JButton("登入");
        sign_in.setBounds(475, 400, 125, 50);
        sign_in.setFont(new Font("微軟正黑體", Font.BOLD, 15));
        add(sign_in);

    }
    public static void main(String[] args) {
        ManagerEnterPort frame = new ManagerEnterPort();
        frame.setVisible(true);
    }
}
