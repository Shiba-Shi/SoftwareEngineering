package SoftwareEngineering;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.io.FileReader;

import org.json.simple.*;
import org.json.simple.parser.*;

public class ManagerEnterPort extends JFrame{
    private JLabel title, password, account;
    private JButton sign_in, sign_up;
    private JFormattedTextField enter_ac, enter_ps;
    private String user_account, user_password, enter_account, enter_password;

    public ManagerEnterPort() {
        this.setTitle("登入");
        this.setLayout(null);
        this.setSize(900, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        title = new JLabel("經理登入");
        title.setBounds(350, 50, 500, 100);
        title.setFont(new Font("微軟正黑體", Font.BOLD, 50));
        add(title);

        account = new JLabel("帳號");
        account.setBounds(250, 200, 100, 100);
        account.setFont(new Font("微軟正黑體", Font.BOLD, 20));
        add(account);

        enter_ac = new JFormattedTextField();
        enter_ac.setBounds(300, 232, 300, 40);
        add(enter_ac);

        password = new JLabel("密碼");
        password.setBounds(250, 275, 100, 100);
        password.setFont(new Font("微軟正黑體", Font.BOLD, 20));
        add(password);

        enter_ps = new JFormattedTextField();
        enter_ps.setBounds(300, 307, 300, 40);
        add(enter_ps);

        sign_up = new JButton("註冊");
        sign_up.setBounds(300, 400, 125, 50);
        sign_up.setFont(new Font("微軟正黑體", Font.BOLD, 15));
        sign_up.addActionListener(new ActionListener() { 
            public void actionPerformed(ActionEvent e) { 
                ManagerSignUp secondframe = new ManagerSignUp();
                secondframe.setVisible(true);
            } 
        });
        add(sign_up);

        sign_in = new JButton("登入");
        sign_in.setBounds(475, 400, 125, 50);
        sign_in.setFont(new Font("微軟正黑體", Font.BOLD, 15));
        sign_in.addActionListener(new ActionListener() { 
            public void actionPerformed(ActionEvent e) { 
                JSONParser parser = new JSONParser();
            try {
                Object obj = parser.parse(new FileReader("user.json"));
                JSONObject jsonObject = (JSONObject)obj;
                user_account = (String) jsonObject.get("account");
                user_password = (String) jsonObject.get("password");
                System.out.println(user_account);
                System.out.println(user_password);
            } catch(Exception k) {
                k.printStackTrace();
            }
                System.out.println(user_account);
                System.out.println(user_password);
                enter_account = enter_ac.getText();
                enter_password = enter_ps.getText();
                if (enter_account.equals(user_account) && enter_password.equals(user_password)) {
                    System.out.printf("登入成功");
                }else {
                    error thirdframe = new error("帳號或密碼錯誤");
                    thirdframe.setVisible(true);
                }
            } 
        });
        add(sign_in);
    }
    public static void main(String[] args) {
        ManagerEnterPort frame = new ManagerEnterPort();
        frame.setVisible(true);
    }
}
